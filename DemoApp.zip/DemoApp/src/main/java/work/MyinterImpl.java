package work;

public class MyinterImpl implements Myinter {
@Override
public void sayhello() {
	// TODO Auto-generated method stub

	System.out.println("I am saying hello");
}
	
	
}
