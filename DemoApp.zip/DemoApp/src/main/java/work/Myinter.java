package work;

@FunctionalInterface
public interface Myinter {
  public abstract void sayhello();
	
	
}
